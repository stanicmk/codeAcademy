package com.example.tutorials_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TutorialsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TutorialsAppApplication.class, args);
	}

}
